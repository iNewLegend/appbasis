<?php
/**
 * @file: config/main.php
 * @author: Leonid Vinikov <czf.leo123@gmail.com>
 */

namespace Config;

class Main extends \Services\Config\Base
{
	public $version = '0.0.1';
} // EOF config/main.php
