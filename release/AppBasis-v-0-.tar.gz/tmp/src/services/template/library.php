<?php
/**
 * @file: library/_NAME.php
 * @author: Name <email@email.com>
 */

namespace Library;

class __NAME
{

} // EOF library/_NAME.php
