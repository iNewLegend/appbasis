<?php
/**
 * @file: modules/_NAME.php
 * @author: Name <email@email.com>
 */

namespace Modules;

class __NAME
{
    /**
     * Function __construct() : Construct _NAME 
     */
    public function __construct()
    {
        $this->initialize();
    }

    /**
     * Function initialize() : Initialize _NAME 
     *
     * @return void
     */
    private function initialize()
    {

    }
} // EOF modules/_NAME.php
