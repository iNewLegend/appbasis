<?php
/**
 * @file: config/_NAME.php
 * @author: Name <email@email.com>
 */

namespace Config;

class __NAME extends \Services\Config\Base
{
} // EOF config/_NAME.php
