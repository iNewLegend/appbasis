<?php

namespace Services\Config;

/**
 * Undocumented interface
 */
interface BaseInterface
{
    # todo: checkout;
    const name = '_BASE_';
    
    /**
     * Undocumented function
     *
     * @return void
     */
    public function getAll();
}
